const cors = require('cors');

/**
 * Configuración de CORS para el sistema SaaS multi-tenant
 */
const corsOptions = {
    origin: function (origin, callback) {
        // Lista de orígenes permitidos desde variables de entorno
        const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(o => o.trim());
        
        // En desarrollo, permitir localhost y requests sin origin
        if (process.env.NODE_ENV === 'development') {
            // Permitir localhost en cualquier puerto para desarrollo
            if (!origin || 
                origin.includes('localhost') || 
                origin.includes('127.0.0.1') ||
                origin.includes('0.0.0.0') ||
                origin.includes('.weekly:5173')) {
                return callback(null, true);
            }
        }
        
        // Para requests internos del servidor (health checks, curl localhost)
        if (!origin) {
            return callback(null, true);
        }
        
        // En producción, permitir automáticamente dominios weekly.pe y getdevtools.com
        if (process.env.NODE_ENV === 'production') {
            // Permitir todos los subdominios de weekly.pe
            if (origin.includes('.weekly.pe') || origin === 'https://weekly.pe' || origin === 'http://weekly.pe') {
                return callback(null, true);
            }
            // Permitir dominios getdevtools.com (para desarrollo en CapRover)
            if (origin.includes('.getdevtools.com') || origin.includes('getdevtools.com')) {
                return callback(null, true);
            }
        }
        
        // Verificar si el origin está en la lista permitida
        const isAllowed = allowedOrigins.some(allowedOrigin => {
            if (!allowedOrigin) return false;
            
            if (allowedOrigin.startsWith('*.')) {
                // Wildcard domain (ej: *.weekly.pe)
                const domain = allowedOrigin.substring(2);
                return origin && origin.endsWith(domain);
            }
            return origin === allowedOrigin;
        });
        
        if (isAllowed) {
            callback(null, true);
        } else {
            console.log(`CORS blocked origin: ${origin}`);
            console.log(`Allowed origins: ${allowedOrigins.join(', ')}`);
            callback(new Error('Not allowed by CORS policy'));
        }
    },
    credentials: true, // Permitir cookies y headers de autenticación
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: [
        'Origin',
        'X-Requested-With',
        'Content-Type',
        'Accept',
        'Authorization',
        'X-Tenant'
    ],
    exposedHeaders: ['X-Tenant', 'X-Total-Count']
};

module.exports = cors(corsOptions);